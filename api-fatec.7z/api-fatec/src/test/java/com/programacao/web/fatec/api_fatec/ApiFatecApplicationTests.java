package com.programacao.web.fatec.api_fatec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFatecApplicationTests {

	@Test
	void contextLoads() {
	}

}
